#include "LinkedList.h"
#include <iostream>

using namespace std;

int main() {
    LinkedList myList;

    myList.insertAtBeginning(5);
    myList.insertAtBeginning(10);
    myList.insertAtEnd(15);
    myList.insertAtEnd(20);

    cout << "Linked List: ";
    myList.display();

    int searchValue = 15;
    if (myList.search(searchValue)) {
        cout << searchValue << " found in the list." << endl;
    } else {
        cout << searchValue << " not found in the list." << endl;
    }

    myList.deleteFromBeginning();
    myList.deleteFromEnd();

    cout << "Linked List after deletion: ";
    myList.display();

    return 0;
}
