#ifndef TREE_H
#define TREE_H

struct Node {
  int data;
  Node* left;
  Node* right;
};

Node* newNode(int data);
void inOrder(Node* root);
void preOrder(Node* root);
void postOrder(Node* root);

#endif

