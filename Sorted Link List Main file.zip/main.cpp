#include "Sorted_List.h"
#include <iostream>

int main() {
    SortedList list;

    list.insertItem(5);
    list.insertItem(2);
    list.insertItem(7);
    list.insertItem(1);

    std::cout << "Sorted List: ";
    list.printList();

    std::cout << "Is 2 in the list? " << (list.searchItem(2) ? "Yes" : "No") << std::endl;
    std::cout << "Is 6 in the list? " << (list.searchItem(6) ? "Yes" : "No") << std::endl;

    std::cout << "Deleting 5 from the list." << std::endl;
    list.deleteItem(5);
    std::cout << "Sorted List after deletion: ";
    list.printList();

    return 0;
}
