
#include <iostream>
#include "Sorted_List.h"

int main() {
    SortedList list(10);

    list.insert(5);
    list.insert(10);
    list.insert(3);
    list.insert(8);

    list.display();

    std::cout << "Search 5: " << (list.search(5) ? "Found" : "Not Found") << std::endl;
    std::cout << "Search 7: " << (list.search(7) ? "Found" : "Not Found") << std::endl;

    list.remove(10);
    list.remove(4);

    list.display();

    return 0;
}
