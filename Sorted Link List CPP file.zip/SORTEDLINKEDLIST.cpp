#ifndef SORTED_LIST_H
#define SORTED_LIST_H

#include <vector>

class SortedList {
private:
    std::vector<int> data;

public:
    // Constructor
    SortedList();

    // Destructor
    ~SortedList();

    // Insert an item into the sorted list
    void insertItem(int item);

    // Search for an item in the sorted list
    bool searchItem(int item);

    // Delete an item from the sorted list
    bool deleteItem(int item);

    // Print the sorted list
    void printList();
};

#endif // SORTED_LIST_H
