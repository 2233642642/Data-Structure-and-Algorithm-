#include "tree.h"
#include <iostream>

int main() {
  Node* root = newNode(11);
  root->left = newNode(9);
  root->right = newNode(4);
  root->left->left = newNode(7);
  root->left->right = newNode(8);
  root->right->left = newNode(3);
  root->right->right = newNode(1);
  root->left->left->left = newNode(2);
  root->left->right->right = newNode(5);
  root->right->left->left = newNode(6);

  // Print in-order traversal
  std::cout << "In-order traversal: ";
  inOrder(root);
  std::cout << std::endl;

  // Print pre-order traversal
  std::cout << "Pre-order traversal: ";
  preOrder(root);
  std::cout << std::endl;

  // Print post-order traversal
  std::cout << "Post-order traversal: ";
  postOrder(root);
  std::cout << std::endl;

  return 0;
}
