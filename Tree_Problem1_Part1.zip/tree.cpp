#include "tree.h"
#include <iostream>

Node* newNode(int data) {
  Node* temp = new Node;
  temp->data = data;
  temp->left = NULL;
  temp->right = NULL;
  return temp;
}

void inOrder(Node* root) {
  if (root != NULL) {
    inOrder(root->left);
    std::cout << root->data << " ";
    inOrder(root->right);
  }
}

void preOrder(Node* root) {
  if (root != NULL) {
    std::cout << root->data << " ";
    preOrder(root->left);
    preOrder(root->right);
  }
}

void postOrder(Node* root) {
  if (root != NULL) {
    postOrder(root->left);
    postOrder(root->right);
    std::cout << root->data << " ";
  }
}
