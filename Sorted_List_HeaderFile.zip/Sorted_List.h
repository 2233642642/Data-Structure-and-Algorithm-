// SortedList.h
#ifndef SORTEDLIST_H
#define SORTEDLIST_H

#include <iostream>

class SortedList {
private:
    int *array;
    int size;
    int capacity;

public:
    SortedList(int capacity);
    ~SortedList();

    void insert(int item);
    bool search(int item);
    void remove(int item);
    void display();
};

#endif // SORTEDLIST_H
