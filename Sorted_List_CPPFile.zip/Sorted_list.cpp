// SortedList.cpp
#include "Sorted_List.h"

SortedList::SortedList(int capacity) {
    this->capacity = capacity;
    this->array = new int[capacity];
    this->size = 0;
}

SortedList::~SortedList() {
    delete[] array;
}

void SortedList::insert(int item) {
    if (size == capacity) {
        std::cout << "List is full. Cannot insert.\n";
        return;
    }

    int i = size - 1;
    while (i >= 0 && array[i] > item) {
        array[i + 1] = array[i];
        i--;
    }
    array[i + 1] = item;
    size++;
}

bool SortedList::search(int item) {
    int left = 0;
    int right = size - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (array[mid] == item) {
            return true;
        } else if (array[mid] < item) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return false;
}

void SortedList::remove(int item) {
    int i = 0;
    while (i < size && array[i] < item) {
        i++;
    }
    if (i < size && array[i] == item) {
        for (int j = i; j < size - 1; j++) {
            array[j] = array[j + 1];
        }
        size--;
        std::cout << "Item removed from the list.\n";
    } else {
        std::cout << "Item not found in the list.\n";
    }
}

void SortedList::display() {
    std::cout << "Sorted List: ";
    for (int i = 0; i < size; i++) {
        std::cout << array[i] << " ";
    }
    std::cout << std::endl;
}
