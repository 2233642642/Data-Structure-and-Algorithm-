/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.graph;
import java.util.*;

public class DFS {
    private Graph graph;
    private boolean[] visited;

    public DFS(Graph graph) {
        this.graph = graph;
        visited = new boolean[graph.getVertices()];
    }

    public void performDFS(int startVertex) {
        System.out.print(startVertex + " ");
        visited[startVertex] = true;

        LinkedList<Integer> adjList[] = graph.getAdjList();
        for (int vertex : adjList[startVertex]) {
            if (!visited[vertex]) {
                performDFS(vertex);
            }
        }
    }
}
