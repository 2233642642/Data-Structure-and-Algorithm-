#ifndef QUEUE_H_INCLUDED
#define QUEUE_H_INCLUDED


#include <iostream>

template <typename T>
class Queue {
private:
    struct Node {
        T data;
        Node* next;
    };
    Node* front;
    Node* rear;

public:
    Queue();
    ~Queue();
    void Enqueue(T value);
    void Dequeue();
    void PrintQueue() const;
    bool IsEmpty() const;
};





#endif // QUEUE_H_INCLUDED
