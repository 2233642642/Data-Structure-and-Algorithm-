#include "Queue.h"

int main() {
    Queue<int> queue;

    std::cout << "Enqueueing 10, 20, 30...\n";
    queue.Enqueue(10);
    queue.Enqueue(20);
    queue.Enqueue(30);

    std::cout << "Current Queue: ";
    queue.PrintQueue();

    std::cout << "Dequeueing...\n";
    queue.Dequeue();

    std::cout << "Current Queue: ";
    queue.PrintQueue();

    std::cout << "Enqueueing 40...\n";
    queue.Enqueue(40);

    std::cout << "Current Queue: ";
    queue.PrintQueue();

    std::cout << "Dequeueing all...\n";
    queue.Dequeue();
    queue.Dequeue();
    queue.Dequeue();

    std::cout << "Current Queue: ";
    queue.PrintQueue();

    return 0;
}
