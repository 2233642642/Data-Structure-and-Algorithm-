#include "Queue.h"

template <typename T>
Queue<T>::Queue() : front(nullptr), rear(nullptr) {}

template <typename T>
Queue<T>::~Queue() {
    while (!IsEmpty()) {
        Dequeue();
    }
}

template <typename T>
void Queue<T>::Enqueue(T value) {
    Node* newNode = new Node{value, nullptr};
    if (rear) {
        rear->next = newNode;
    } else {
        front = newNode;
    }
    rear = newNode;
}

template <typename T>
void Queue<T>::Dequeue() {
    if (IsEmpty()) {
        std::cout << "Queue is empty.\n";
        return;
    }
    Node* temp = front;
    front = front->next;
    if (!front) {
        rear = nullptr;
    }
    delete temp;
}

template <typename T>
void Queue<T>::PrintQueue() const {
    Node* current = front;
    while (current) {
        std::cout << current->data << " ";
        current = current->next;
    }
    std::cout << std::endl;
}

template <typename T>
bool Queue<T>::IsEmpty() const {
    return front == nullptr;
}

// Explicit template instantiation
template class Queue<int>;
template class Queue<float>;
template class Queue<double>;
template class Queue<std::string>;
